import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'

export const supportedCurrencies = [
  { code: 'INR', name: 'Indian rupee', locale: 'en-IN' },
  { code: 'USD', name: 'US dollar', locale: 'en-US' },
  { code: 'EUR', name: 'Euro', locale: 'en-IE' },
  { code: 'GBP', name: 'British pound', locale: 'en-GB' },
  { code: 'CAD', name: 'Canadian dollar', locale: 'en-CA' },
  { code: 'AUD', name: 'Australian dollar', locale: 'en-AU' },
  { code: 'SGD', name: 'Singapore dollar', locale: 'en-SG' },
  { code: 'AED', name: 'UAE dirham', locale: 'en-AE' },
] as const

export type CurrencyCode = typeof supportedCurrencies[number]['code']
type CurrencyPreference = CurrencyCode | 'auto'
type CurrencyRates = Partial<Record<CurrencyCode, number>> & { INR: number }

type CurrencyContextValue = {
  currency: CurrencyCode
  preference: CurrencyPreference
  rates: CurrencyRates
  rateStatus: 'loading' | 'ready' | 'unavailable'
  setPreference: (preference: CurrencyPreference) => void
  formatMoney: (inrAmount: number) => string
}

const CurrencyContext = createContext<CurrencyContextValue | null>(null)
const PREFERENCE_KEY = 'basket-fast-currency-preference'
const RATES_KEY = 'basket-fast-currency-rates'
const RATE_CACHE_AGE = 12 * 60 * 60 * 1000

function isCurrencyCode(value: string): value is CurrencyCode {
  return supportedCurrencies.some((currency) => currency.code === value)
}

function getSavedPreference(): CurrencyPreference {
  if (typeof window === 'undefined') return 'auto'
  try {
    const saved = window.localStorage.getItem(PREFERENCE_KEY)
    if (saved === 'auto' || (saved && isCurrencyCode(saved))) return saved
  } catch {
    // Storage can be unavailable in private or restricted browsing contexts.
  }
  return 'auto'
}

function getCachedRates(): CurrencyRates | null {
  try {
    const cached = window.localStorage.getItem(RATES_KEY)
    if (!cached) return null
    const parsed = JSON.parse(cached) as { savedAt?: number; rates?: Record<string, number> }
    if (!parsed.savedAt || Date.now() - parsed.savedAt > RATE_CACHE_AGE || !parsed.rates) return null

    const rates: CurrencyRates = { INR: 1 }
    for (const { code } of supportedCurrencies) {
      const rate = parsed.rates[code]
      if (typeof rate === 'number' && Number.isFinite(rate) && rate > 0) rates[code] = rate
    }
    return rates
  } catch {
    return null
  }
}

const currencyByRegion: Record<string, CurrencyCode> = {
  US: 'USD', CA: 'CAD', GB: 'GBP', AU: 'AUD', SG: 'SGD', AE: 'AED', IN: 'INR',
  AT: 'EUR', BE: 'EUR', CY: 'EUR', DE: 'EUR', EE: 'EUR', ES: 'EUR', FI: 'EUR',
  FR: 'EUR', GR: 'EUR', HR: 'EUR', IE: 'EUR', IT: 'EUR', LT: 'EUR', LU: 'EUR',
  LV: 'EUR', MT: 'EUR', NL: 'EUR', PT: 'EUR', SI: 'EUR', SK: 'EUR',
}

function getBrowserCurrency(): CurrencyCode | null {
  try {
    const region = new Intl.Locale(navigator.language).region
    return region ? currencyByRegion[region] ?? null : null
  } catch {
    return null
  }
}

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [preference, setPreferenceState] = useState<CurrencyPreference>(getSavedPreference)
  const [currency, setCurrency] = useState<CurrencyCode>('INR')
  const [rates, setRates] = useState<CurrencyRates>(() => getCachedRates() ?? { INR: 1 })
  const [rateStatus, setRateStatus] = useState<'loading' | 'ready' | 'unavailable'>(() => getCachedRates() ? 'ready' : 'loading')

  useEffect(() => {
    if (rateStatus === 'ready') return
    let active = true

    fetch('https://open.er-api.com/v6/latest/INR')
      .then(async (response) => {
        if (!response.ok) throw new Error('Exchange-rate service unavailable')
        return response.json() as Promise<{ result?: string; rates?: Record<string, number> }>
      })
      .then((data) => {
        if (data.result !== 'success' || !data.rates) throw new Error('Invalid exchange-rate response')
        const freshRates: CurrencyRates = { INR: 1 }
        for (const { code } of supportedCurrencies) {
          const rate = data.rates[code]
          if (typeof rate === 'number' && Number.isFinite(rate) && rate > 0) freshRates[code] = rate
        }
        if (!active) return
        setRates(freshRates)
        setRateStatus('ready')
        try {
          window.localStorage.setItem(RATES_KEY, JSON.stringify({ savedAt: Date.now(), rates: freshRates }))
        } catch {
          // Currency conversion still works for this visit without a cache.
        }
      })
      .catch(() => {
        if (active) {
          setRates({ INR: 1 })
          setRateStatus('unavailable')
        }
      })

    return () => { active = false }
  }, [rateStatus])

  useEffect(() => {
    if (rateStatus === 'loading') return
    if (preference !== 'auto') {
      setCurrency(rates[preference] ? preference : 'INR')
      return
    }

    let active = true
    const applyCountryCurrency = (candidate: string | null | undefined) => {
      if (candidate && isCurrencyCode(candidate) && rates[candidate] && active) setCurrency(candidate)
    }

    fetch('https://ipapi.co/json/')
      .then(async (response) => {
        if (!response.ok) throw new Error('Location service unavailable')
        return response.json() as Promise<{ currency?: string }>
      })
      .then((location) => applyCountryCurrency(location.currency))
      .catch(() => applyCountryCurrency(getBrowserCurrency()))

    return () => { active = false }
  }, [preference, rateStatus, rates])

  const setPreference = (next: CurrencyPreference) => {
    setPreferenceState(next)
    if (next === 'auto') {
      setCurrency('INR')
    } else {
      setCurrency(rates[next] ? next : 'INR')
    }
    try {
      window.localStorage.setItem(PREFERENCE_KEY, next)
    } catch {
      // The selection remains active for this visit if storage is unavailable.
    }
  }

  const formatMoney = useMemo(() => (inrAmount: number) => {
    const activeCurrency = rates[currency] ? currency : 'INR'
    const rate = rates[activeCurrency] ?? 1
    const locale = supportedCurrencies.find((item) => item.code === activeCurrency)?.locale ?? 'en-IN'
    const amount = inrAmount * rate
    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: activeCurrency,
      maximumFractionDigits: activeCurrency === 'INR' ? 0 : 2,
    }).format(amount)
  }, [currency, rates])

  const value = useMemo(
    () => ({ currency, preference, rates, rateStatus, setPreference, formatMoney }),
    [currency, preference, rates, rateStatus, formatMoney],
  )

  return <CurrencyContext.Provider value={value}>{children}</CurrencyContext.Provider>
}

export function useCurrency() {
  const context = useContext(CurrencyContext)
  if (!context) throw new Error('useCurrency must be used inside CurrencyProvider')
  return context
}