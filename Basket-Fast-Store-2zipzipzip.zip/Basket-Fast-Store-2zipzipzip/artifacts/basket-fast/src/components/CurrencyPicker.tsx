import { Globe2 } from 'lucide-react'
import { supportedCurrencies, useCurrency, type CurrencyCode } from '@/lib/currency'

export function CurrencyPicker() {
  const { currency, preference, rates, rateStatus, setPreference } = useCurrency()
  const selectedValue = preference === 'auto' || !rates[preference] ? 'auto' : preference

  return (
    <label
      className="currency-picker"
      title={
        rateStatus === 'unavailable'
          ? 'Live rates unavailable. Prices are shown in INR.'
          : 'Choose a currency or let Basket Fast detect your country.'
      }
    >
      <Globe2 size={15} aria-hidden="true" />
      <select
        aria-label="Store currency"
        value={selectedValue}
        onChange={(event) => setPreference(event.target.value as CurrencyCode | 'auto')}
      >
        <option value="auto">Auto · {currency}</option>
        {supportedCurrencies.map(({ code, name }) => (
          <option key={code} value={code} disabled={!rates[code]}>
            {code} — {name}
          </option>
        ))}
      </select>
    </label>
  )
}