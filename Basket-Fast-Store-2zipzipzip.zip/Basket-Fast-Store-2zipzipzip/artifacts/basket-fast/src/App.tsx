import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react'
import {
  ArrowDown, ArrowRight, ArrowUpRight, Check, ChevronDown, CircleHelp, CreditCard,
  Eye, Filter, Heart, Instagram, LayoutDashboard, Lock, Mail, Menu, MessageCircle,
  Package, Pencil, Plus, RefreshCw, Search, Send, Settings, ShieldCheck, ShoppingBag, ShoppingCart,
  Sparkles, Star, Truck, Twitter, UserRound, X, Zap,
} from 'lucide-react'
import { CurrencyPicker } from '@/components/CurrencyPicker'
import { CurrencyProvider, useCurrency } from '@/lib/currency'

type View = 'home' | 'shop' | 'collections' | 'about' | 'journal' | 'policies' | 'contact' | 'loading' | 'offline' | 'admin' | 'notfound'
type Product = {
  id: number; name: string; category: string; price: number; oldPrice?: number; badge?: string
  colors: string[]; sizes: string[]; images: string[]; image: string; description: string; tag: string; rating: number; reviews: number
  selectedSize?: string; selectedColor?: string
}

type CatalogRecord = {
  id: number; name: string; category: string; description: string | null; price: number
  offerPrice: number | null; isLimited: boolean; colors: string[]; sizes: string[]
  image: string; averageRating: number; reviewCount: number
}
type AdminOrder = {
  id: number; customerName: string; email: string | null; phone: string; address: string
  items: { productId: number; name: string; category: string; price: number; quantity: number; size: string | null; image: string }[]
  total: number; status: 'pending' | 'confirmed' | 'packed' | 'shipped' | 'delivered' | 'cancelled'; createdAt: string
}
type AdminOverview = { productCount: number; orderCount: number; pendingOrderCount: number; reviewCount: number; recentOrders: AdminOrder[] }

const toProduct = (record: CatalogRecord): Product => ({
  id: record.id,
  name: record.name,
  category: record.category,
  price: record.offerPrice ?? record.price,
  oldPrice: record.offerPrice ? record.price : undefined,
  badge: record.isLimited ? 'Limited' : undefined,
  colors: record.colors,
  sizes: record.sizes,
  images: record.images.length ? record.images : [record.image],
  image: record.image,
  description: record.description || 'A daily essential with enough personality to stand out.',
  tag: record.description || 'Store piece',
  rating: record.averageRating,
  reviews: record.reviewCount,
})
const FREE_SHIPPING_THRESHOLD = 6500
const tickerPhrases = ['NO BENCHWARMERS', 'BUILT FOR THE FOURTH', 'PLAY LOUD', 'MADE FOR THE FAST', 'OWN YOUR PACE', 'COURT TO STREET']

const routeViews: Record<string, View> = {
  '/': 'home', '/shop': 'shop', '/collections': 'collections', '/about': 'about',
  '/journal': 'journal', '/policies': 'policies', '/contact': 'contact',
  '/loading': 'loading', '/offline': 'offline', '/admin': 'admin', '/not-found': 'notfound',
}
const getViewFromLocation = (): View => {
  const hash = window.location.hash.replace(/^#/, '')
  if (hash && routeViews[`/${hash}`]) return routeViews[`/${hash}`]
  return routeViews[window.location.pathname] || 'notfound'
}

export default function App() {
  return <CurrencyProvider><Storefront /></CurrencyProvider>
}

function Storefront() {
  const [view, setView] = useState<View>(() => getViewFromLocation())
  const [catalog, setCatalog] = useState<Product[]>([])
  const [category, setCategory] = useState('All pieces')
  const [query, setQuery] = useState('')
  const [cart, setCart] = useState<Product[]>([])
  const [cartOpen, setCartOpen] = useState(false)
  const [selected, setSelected] = useState<Product | null>(null)
  const [chatOpen, setChatOpen] = useState(false)
  const [feedbackOpen, setFeedbackOpen] = useState(false)
  const [mobileMenu, setMobileMenu] = useState(false)
  const [policy, setPolicy] = useState<string | null>(null)
  const offlineReturnPath = useRef('/')

  useEffect(() => {
    const sync = () => {
      const next = getViewFromLocation()
      if (next === 'offline' && window.navigator.onLine) {
        window.history.replaceState({}, '', '/')
        setView('home')
        return
      }
      setView(next)
    }
    const goOffline = () => {
      if (window.location.pathname !== '/offline') offlineReturnPath.current = window.location.pathname
      window.history.pushState({}, '', '/offline')
      setView('offline')
    }
    const goOnline = () => {
      if (window.location.pathname === '/offline') {
        window.history.replaceState({}, '', offlineReturnPath.current || '/')
        setView(getViewFromLocation())
      }
    }
    sync()
    window.addEventListener('popstate', sync)
    window.addEventListener('hashchange', sync)
    window.addEventListener('offline', goOffline)
    window.addEventListener('online', goOnline)
    if (!window.navigator.onLine) goOffline()
    return () => {
      window.removeEventListener('popstate', sync)
      window.removeEventListener('hashchange', sync)
      window.removeEventListener('offline', goOffline)
      window.removeEventListener('online', goOnline)
    }
  }, [])
  useEffect(() => {
    let active = true
    fetch('/api/products', { credentials: 'same-origin' })
      .then((response) => response.ok ? response.json() as Promise<CatalogRecord[]> : Promise.reject(new Error('catalog-unavailable')))
      .then((data) => active && setCatalog(data.map(toProduct)))
      .catch(() => active && setCatalog([]))
    return () => { active = false }
  }, [])
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => entries.forEach((entry) => entry.isIntersecting && entry.target.classList.add('visible')), { threshold: .12 })
    document.querySelectorAll('.reveal').forEach((item) => observer.observe(item))
    return () => observer.disconnect()
  }, [view])

  const navigate = (next: View) => {
    setMobileMenu(false)
    const path = next === 'home' ? '/' : `/${next}`
    window.history.pushState({}, '', path)
    setView(next)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }
  const categories = useMemo(() => ['All pieces', ...Array.from(new Set(catalog.map((item) => item.category)))], [catalog])
  const filtered = useMemo(() => catalog.filter((item) => (category === 'All pieces' || item.category === category) && `${item.name} ${item.category}`.toLowerCase().includes(query.toLowerCase())), [catalog, category, query])
  const add = (product: Product, options?: { size?: string; color?: string }) => {
    setCart((items) => [...items, { ...product, selectedSize: options?.size, selectedColor: options?.color }])
    setSelected(null)
    setCartOpen(true)
  }
  const saveProduct = async (product: Product) => {
    const payload = {
      name: product.name,
      category: product.category,
      price: product.oldPrice ?? product.price,
      offerPrice: product.oldPrice ? product.price : null,
      isLimited: product.badge === 'Limited',
      description: product.description || product.tag || null,
      colors: product.colors,
      sizes: product.sizes.length ? product.sizes : ['One size'],
      images: product.images.length ? product.images : [product.image],
    }
    const response = await fetch(product.id > 0 ? `/api/admin/products/${product.id}` : '/api/admin/products', {
      method: product.id > 0 ? 'PATCH' : 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
    if (!response.ok) throw new Error('product-save-failed')
    const saved = toProduct(await response.json() as CatalogRecord)
    setCatalog((items) => items.some((item) => item.id === saved.id) ? items.map((item) => item.id === saved.id ? saved : item) : [saved, ...items])
  }

  const utilityRoute = view === 'admin' || view === 'loading' || view === 'offline' || view === 'notfound'
  return <div className="app-shell">
    {!utilityRoute && <><Announcement /><Header view={view} cartCount={cart.length} mobileMenu={mobileMenu} setMobileMenu={setMobileMenu} navigate={navigate} onCart={() => setCartOpen(true)} /></>}
    <main>
      {view === 'home' && <Home products={catalog} navigate={navigate} add={add} quick={setSelected} setCategory={(next) => { setCategory(next); navigate('shop') }} />}
      {view === 'shop' && <Shop products={filtered} categories={categories} category={category} setCategory={setCategory} query={query} setQuery={setQuery} add={add} quick={setSelected} />}
      {view === 'collections' && <Collections setCategory={(next) => { setCategory(next); navigate('shop') }} />}
      {view === 'about' && <About navigate={navigate} />}
      {view === 'journal' && <Journal />}
      {view === 'policies' && <Policies open={setPolicy} />}
      {view === 'contact' && <Contact />}
      {view === 'loading' && <LoadingScreen navigate={navigate} />}
      {view === 'offline' && <OfflineScreen navigate={navigate} />}
      {view === 'notfound' && <NotFound navigate={navigate} />}
      {view === 'admin' && <Admin products={catalog} onSave={saveProduct} />}
    </main>
    {!utilityRoute && <><Footer navigate={navigate} openPolicy={setPolicy} /><Feedback onOpen={() => setFeedbackOpen(true)} /><Chat open={chatOpen} setOpen={setChatOpen} />
      {selected && <ProductModal product={selected} close={() => setSelected(null)} add={add} />}
      {cartOpen && <Cart cart={cart} close={() => setCartOpen(false)} remove={(id, index) => setCart((items) => items.filter((item, itemIndex) => item.id !== id || itemIndex !== index))} />}
      {policy && <PolicyModal title={policy} close={() => setPolicy(null)} />}
      {feedbackOpen && <FeedbackModal close={() => setFeedbackOpen(false)} />}
    </>}
  </div>
}

function Announcement() { const { formatMoney } = useCurrency(); return <div className="announcement"><span><Zap size={13} fill="currentColor" /> Free shipping on orders over {formatMoney(FREE_SHIPPING_THRESHOLD)}</span><span className="announcement-separator">/</span><span>New season. Same energy.</span><span className="announcement-link">Shop the drop <ArrowRight size={13} /></span></div> }

function Header({ view, cartCount, mobileMenu, setMobileMenu, navigate, onCart }: { view: View; cartCount: number; mobileMenu: boolean; setMobileMenu: (value: boolean) => void; navigate: (view: View) => void; onCart: () => void }) {
  return <header className="site-header"><button className="mobile-menu-button" aria-label="Open menu" onClick={() => setMobileMenu(!mobileMenu)}><Menu size={22} /></button><button className="brand" onClick={() => navigate('home')}><img src="/basket-logo.png" alt="Basket logo" /><span>BASKET <b>FAST</b></span></button><nav className={`main-nav ${mobileMenu ? 'open' : ''}`}>{[['shop', 'Shop'], ['collections', 'Collections'], ['about', 'Our story'], ['journal', 'Journal']].map(([key, label]) => <button key={key} className={view === key ? 'active' : ''} onClick={() => navigate(key as View)}>{label}</button>)}</nav><div className="header-actions"><button className="icon-button desktop-only" aria-label="Search the catalog" onClick={() => navigate('shop')}><Search size={19} /></button><CurrencyPicker /><button className="cart-button" onClick={onCart}><ShoppingBag size={19} /><span>Bag</span>{cartCount > 0 && <b>{cartCount}</b>}</button></div></header>
}

function Home({ products, navigate, add, quick, setCategory }: { products: Product[]; navigate: (view: View) => void; add: (product: Product) => void; quick: (product: Product) => void; setCategory: (category: string) => void }) {
  const countFor = (category: string) => `${products.filter((product) => product.category === category).length} pieces`
  return <><section className="hero"><div className="hero-copy"><div className="eyebrow"><span className="eyebrow-dot" /> SS26 / Court-side essentials</div><h1>Made for<br /><em>the fast.</em></h1><p>Game-day energy, everyday wear. Fresh pieces for the ones who bring their own pace.</p><div className="hero-actions"><button className="button button-dark" onClick={() => navigate('shop')}>Shop new arrivals <ArrowUpRight size={17} /></button><button className="text-button" onClick={() => navigate('about')}>Our story <ArrowRight size={16} /></button></div><div className="hero-note"><span className="mini-avatars"><i /><i /><i /></span><span>{products.length} pieces currently in the rotation</span></div></div><div className="hero-art"><div className="hero-orange-disc" /><div className="hero-grid-lines" /><div className="hero-image-main image-float"><img src="/editorial-court.jpg" alt="Basketball player in motion" /></div><div className="hero-image-small image-float-delayed"><img src="/lifestyle-hoop.jpg" alt="Player reaching for a basketball rim" /></div><div className="hero-sticker"><Sparkles size={16} /><span>Move<br />different.</span></div><div className="hero-scroll"><ArrowDown size={15} /> Scroll to explore</div></div></section><div className="ticker"><div className="ticker-track">{[0, 1].map((copy) => <span key={copy} aria-hidden={copy === 1}>{tickerPhrases.map((phrase) => <span className="ticker-item" key={phrase}><b>{phrase}</b><i>/</i></span>)}</span>)}</div></div><section className="section featured-section"><div className="section-heading reveal"><div><span className="section-kicker">01 / The rotation</span><h2>Fresh off<br /><em>the court.</em></h2></div><div className="heading-side"><p>Pieces with a little more bounce. Designed in our studio, tested outside the lines.</p><button className="text-button" onClick={() => navigate('shop')}>View all pieces <ArrowRight size={16} /></button></div></div><div className="product-grid product-grid-home">{products.slice(0, 4).map((product, index) => <ProductCard key={product.id} product={product} index={index} add={add} quick={quick} />)}</div></section><section className="section statement-section reveal"><div className="statement-visual"><img src="/lifestyle-court.jpg" alt="Friends walking beside an outdoor court" /><span className="vertical-label">BASKET FAST / 2026</span></div><div className="statement-copy"><span className="section-kicker">02 / Our point of view</span><h2>Don’t wait<br />for the <em>perfect</em><br />moment.</h2><p>We make uniforms for the daily game. The early runs, the late-night courts, the fit that turns a regular Tuesday into something worth showing up for.</p><button className="button button-orange" onClick={() => navigate('about')}>Get to know us <ArrowUpRight size={17} /></button></div></section><section className="section category-section"><div className="section-heading reveal"><div><span className="section-kicker">03 / Find your lane</span><h2>Pick your<br /><em>energy.</em></h2></div><p className="heading-side">Your game, your uniform. Find the piece that keeps up.</p></div><div className="category-grid"><Category title="Jerseys" count={countFor('Jerseys')} image="/lifestyle-hoop.jpg" click={() => setCategory('Jerseys')} /><Category title="Daily rotation" count={countFor('T-shirts')} image="/lifestyle-court.jpg" click={() => setCategory('T-shirts')} /><Category title="Accessories" count={countFor('Accessories')} image="/material-detail.jpg" click={() => setCategory('Accessories')} /></div></section><section className="newsletter reveal"><div><span className="section-kicker light">04 / Stay in the game</span><h2>Good things<br /><em>come fast.</em></h2></div><Newsletter /></section></>
}

function Newsletter() { const [email, setEmail] = useState(''); const [sent, setSent] = useState(false); return <div className="newsletter-form"><p>Drop your email for first dibs on new drops, court stories, and 10% off your first order.</p>{sent ? <div className="newsletter-success"><Check size={18} /> You’re on the list. Welcome to the rotation.</div> : <><div className="email-input"><input value={email} onChange={(event) => setEmail(event.target.value)} placeholder="Your email address" type="email" /><button aria-label="Join the mailing list" onClick={() => email.includes('@') && setSent(true)}><ArrowRight size={19} /></button></div><small><Lock size={11} /> No spam. Just good stuff.</small></>}</div> }

function Category({ title, count, image, click }: { title: string; count: string; image: string; click: () => void }) { return <button className="category-tile reveal" onClick={click}><img src={image} alt={title} /><span className="category-overlay" /><span className="category-info"><small>{count}</small><strong>{title}</strong><ArrowUpRight size={20} /></span></button> }

function ProductCard({ product, index, add, quick }: { product: Product; index: number; add: (product: Product) => void; quick: (product: Product) => void }) {
  const { formatMoney: money } = useCurrency()
  const [liked, setLiked] = useState(false)
  return <article className={`product-card reveal delay-${(index % 4) + 1}`}><div className="product-image-wrap" onClick={() => quick(product)}>{product.badge && <span className="product-badge">{product.badge}</span>}<img src={product.image} alt={product.name} className="product-image" /><button className="quick-view" onClick={(event) => { event.stopPropagation(); quick(product) }}>Quick view <ArrowUpRight size={15} /></button><button className={`heart-button ${liked ? 'liked' : ''}`} aria-label={liked ? 'Remove from wishlist' : 'Add to wishlist'} onClick={(event) => { event.stopPropagation(); setLiked(!liked) }}><Heart size={17} fill={liked ? 'currentColor' : 'none'} /></button></div><div className="product-info"><div className="product-meta"><span>{product.category}</span><span className="rating">{product.rating > 0 ? <><Star size={12} fill="currentColor" /> {product.rating} ({product.reviews})</> : 'New piece'}</span></div><div className="product-name-row"><h3>{product.name}</h3><button className="add-button" onClick={() => add(product)} aria-label={`Add ${product.name} to bag`}><Plus size={18} /></button></div><div className="product-bottom"><span>{money(product.price)} {product.oldPrice && <del>{money(product.oldPrice)}</del>}</span><span className="swatches">{product.colors.map((color) => <i key={color} style={{ background: color }} />)}</span></div></div></article>
}

function Shop({ products, categories, category, setCategory, query, setQuery, add, quick }: { products: Product[]; categories: string[]; category: string; setCategory: (value: string) => void; query: string; setQuery: (value: string) => void; add: (product: Product) => void; quick: (product: Product) => void }) { return <section className="shop-page"><div className="page-intro"><span className="section-kicker">Shop / All pieces</span><h1>Find your<br /><em>next uniform.</em></h1><p>Thoughtfully made pieces for warm-ups, walk-ins, and everything after the final buzzer.</p></div><div className="shop-toolbar"><div className="category-pills">{categories.map((item) => <button key={item} className={category === item ? 'selected' : ''} onClick={() => setCategory(item)}>{item}</button>)}</div><label className="search-box"><Search size={17} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search pieces..." /></label></div><div className="shop-result-line"><span>{products.length} pieces</span><button><Filter size={15} /> Filters <ChevronDown size={14} /></button></div><div className="product-grid shop-grid">{products.length ? products.map((product, index) => <ProductCard key={product.id} product={product} index={index} add={add} quick={quick} />) : <div className="empty-state"><Search size={30} /><h3>No pieces found.</h3><p>Try a different search or reset your lane.</p><button className="button button-dark" onClick={() => { setQuery(''); setCategory('All pieces') }}>Reset shop</button></div>}</div></section> }

function Collections({ setCategory }: { setCategory: (value: string) => void }) { return <section className="collections-page"><div className="page-intro centered"><span className="section-kicker">Collections / Curated</span><h1>Built around<br /><em>the game.</em></h1><p>Three ways to enter the rotation. Pick a lane, then make it yours.</p></div><div className="collection-feature"><div className="collection-feature-image"><img src="/lifestyle-hoop.jpg" alt="Basketball player in motion" /><span>01</span></div><div className="collection-feature-copy"><span className="section-kicker">The starting five</span><h2>Uniforms for<br /><em>every day.</em></h2><p>The pieces that carry the whole week. Clean lines, reliable weight, and just enough orange to make a statement.</p><button className="button button-dark" onClick={() => setCategory('Jerseys')}>Explore jerseys <ArrowUpRight size={17} /></button></div></div><div className="collection-cards"><CategoryCard number="02" title="Off-court club" text="For the walk-in, the warm-up, and the after." image="/lifestyle-court.jpg" click={() => setCategory('T-shirts')} /><CategoryCard number="03" title="The extras" text="Small details. Big main-character energy." image="/material-detail.jpg" click={() => setCategory('Accessories')} /></div></section> }
function CategoryCard({ number, title, text, image, click }: { number: string; title: string; text: string; image: string; click: () => void }) { return <button className="collection-card" onClick={click}><img src={image} alt={title} /><span className="category-overlay" /><span className="collection-card-number">{number}</span><span className="collection-card-info"><strong>{title}</strong><small>{text}</small><span>Shop collection <ArrowUpRight size={15} /></span></span></button> }

function About({ navigate }: { navigate: (view: View) => void }) { return <section className="about-page"><div className="page-intro"><span className="section-kicker">Our story / Since 2019</span><h1>We keep<br /><em>showing up.</em></h1><p>Basket Fast started with one jersey, one camera, and a belief that what you wear should feel like a little extra fuel.</p></div><div className="about-collage"><div className="about-large"><img src="/editorial-court.jpg" alt="Basketball player stretching" /><span>01 / Keep moving</span></div><div className="about-small"><img src="/material-detail.jpg" alt="Basketball apparel materials" /><span>02 / Play loud</span></div></div><div className="about-principles"><span className="section-kicker">What we believe</span><div className="principle-list"><div><span>01</span><h3>Function first.</h3><p>Every cut, fabric, and pocket earns its place. Good looking is the baseline.</p></div><div><span>02</span><h3>Nothing generic.</h3><p>Small-batch designs made for people who would rather set the tone than follow it.</p></div><div><span>03</span><h3>Keep it moving.</h3><p>We design for real life — the scuffed, sweaty, unpredictable version.</p></div></div></div><div className="about-cta"><h2>Want to wear<br /><em>the energy?</em></h2><button className="button button-orange" onClick={() => navigate('shop')}>Shop the rotation <ArrowUpRight size={17} /></button></div></section> }

function Journal() { const stories = [['01', 'The art of the fourth quarter', 'Mindset', 'How to make the last five minutes your best five.', '/lifestyle-hoop.jpg'], ['02', 'Uniform study: orange after dark', 'Style notes', 'Why the best color on court is the one you make yours.', '/editorial-court.jpg'], ['03', 'Meet the makers: Jaipur edition', 'Behind the scenes', 'A look at the hands and ideas behind every Basket Fast piece.', '/material-detail.jpg']]; return <section className="journal-page"><div className="page-intro centered"><span className="section-kicker">Journal / Dispatches</span><h1>Notes from<br /><em>the sideline.</em></h1><p>Stories, style, and a few things we’re learning while we keep moving.</p></div><div className="journal-list">{stories.map((story) => <article className="journal-card" key={story[0]}><div className="journal-image"><img src={story[4]} alt={story[1]} /><span>{story[0]}</span></div><div className="journal-copy"><span className="section-kicker">{story[2]}</span><h2>{story[1]}</h2><p>{story[3]}</p><button className="text-button">Read story <ArrowRight size={16} /></button></div></article>)}</div></section> }

function Policies({ open }: { open: (title: string) => void }) { const items = [['Shipping & delivery', 'How fast your pieces get to you.', Truck], ['Returns & exchanges', 'Not the right fit? We’ve got you.', Package], ['Privacy policy', 'Your data stays yours.', ShieldCheck], ['Terms of service', 'The rules of the game.', ShieldCheck]] as const; return <section className="policies-page"><div className="page-intro centered"><span className="section-kicker">The fine print / Clear & simple</span><h1>Good to<br /><em>know.</em></h1><p>Everything you need before you press play. No confusing language, promise.</p></div><div className="policy-grid">{items.map(([title, text, Icon]) => <button className="policy-card" key={title} onClick={() => open(title)}><span className="policy-icon"><Icon size={22} /></span><strong>{title}</strong><p>{text}</p><ArrowUpRight size={18} /></button>)}</div></section> }

function AdminDashboard({ products, onSave, onLogout }: { products: Product[]; onSave: (product: Product) => void; onLogout: () => void }) {
  const [editor, setEditor] = useState<Product | null | false>(false)
  const edit = (product?: Product) => setEditor(product || null)
  return <section className="admin-page"><aside className="admin-sidebar"><div className="admin-logo"><img src="/basket-logo.png" alt="" /><span>Basket<br /><b>Fast</b></span></div><span className="admin-label">Workspace</span><button className="admin-nav active"><LayoutDashboard size={17} /> Overview</button><button className="admin-nav"><Package size={17} /> Products <span>{products.length}</span></button><button className="admin-nav"><ShoppingCart size={17} /> Orders <span>8</span></button><button className="admin-nav"><Star size={17} /> Reviews</button><span className="admin-label">Manage</span><button className="admin-nav"><Settings size={17} /> Settings</button><div className="admin-user"><span className="avatar">BF</span><span><b>Basket Fast</b><small>Store admin</small></span><ChevronDown size={15} /></div></aside><div className="admin-main"><div className="admin-topbar"><div><span className="section-kicker">Thursday, 24 September 2026</span><h1>Good morning, team <span className="admin-mark">+</span></h1></div><div className="admin-top-actions"><button className="icon-button" aria-label="Open help"><CircleHelp size={18} /></button><button className="button admin-logout" onClick={onLogout}>Log out</button><button className="button button-dark" onClick={() => edit()}><Plus size={16} /> Add product</button></div></div><div className="admin-stats"><Stat icon={CreditCard} label="Gross revenue" value="$12,482.80" change="+18.4%" /><Stat icon={ShoppingCart} label="Orders" value="184" change="+12.8%" /><Stat icon={UserRound} label="New customers" value="92" change="+24.1%" /><Stat icon={Eye} label="Store visits" value="8,420" change="+9.6%" /></div><div className="admin-grid"><div className="panel sales-panel"><div className="panel-heading"><div><h2>Sales overview</h2><span>Last 30 days</span></div><button className="date-button">Sep 01 — Sep 30 <ChevronDown size={15} /></button></div><div className="chart-area"><div className="chart-y"><span>$4k</span><span>$3k</span><span>$2k</span><span>$1k</span><span>$0</span></div><div className="chart"><div className="chart-grid-lines"><i /><i /><i /><i /><i /></div><svg viewBox="0 0 680 240" preserveAspectRatio="none"><defs><linearGradient id="salesFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#ff681f" stopOpacity=".28" /><stop offset="100%" stopColor="#ff681f" stopOpacity="0" /></linearGradient></defs><path d="M0 211 C44 199, 52 201, 88 180 S142 189, 175 151 S238 169, 268 132 S320 147, 349 105 S401 123, 436 83 S487 111, 522 58 S575 93, 608 46 S655 53, 680 19 V240 H0Z" fill="url(#salesFill)" /><path d="M0 211 C44 199, 52 201, 88 180 S142 189, 175 151 S238 169, 268 132 S320 147, 349 105 S401 123, 436 83 S487 111, 522 58 S575 93, 608 46 S655 53, 680 19" fill="none" stroke="#ff681f" strokeWidth="3" /></svg><div className="chart-x"><span>Sep 01</span><span>Sep 08</span><span>Sep 15</span><span>Sep 22</span><span>Sep 30</span></div></div></div></div><div className="panel top-products"><div className="panel-heading"><div><h2>Top products</h2><span>By units sold</span></div><button className="text-button">View all <ArrowRight size={15} /></button></div><div className="top-product-list">{products.slice(0, 4).map((product, index) => <div className="top-product" key={product.id}><span className="top-rank">0{index + 1}</span><img src={product.image} alt="" /><span className="top-product-name"><b>{product.name}</b><small>{product.category}</small></span><strong>{[82, 67, 54, 38][index]}</strong><button className="admin-edit" onClick={() => edit(product)}><Pencil size={13} /></button></div>)}</div></div></div><div className="panel recent-orders"><div className="panel-heading"><div><h2>Recent orders</h2><span>Latest activity in your store</span></div><button className="text-button">View orders <ArrowRight size={15} /></button></div><table><thead><tr><th>Order</th><th>Customer</th><th>Product</th><th>Date</th><th>Total</th><th>Status</th></tr></thead><tbody>{[['#BF-1048', 'Maya Patel', 'Fast Break Jersey', 'Today, 11:42', '$64.00', 'Shipped'], ['#BF-1047', 'Liam Carter', 'Orange Court Hoodie', 'Today, 10:18', '$82.00', 'Processing'], ['#BF-1046', 'Noah Williams', 'Baseline Script Tee', 'Yesterday, 18:22', '$38.00', 'Delivered']].map((order) => <tr key={order[0]}><td><b>{order[0]}</b></td><td>{order[1]}</td><td>{order[2]}</td><td>{order[3]}</td><td><b>{order[4]}</b></td><td><span className={`status ${order[5].toLowerCase()}`}>{order[5]}</span></td></tr>)}</tbody></table></div></div>{editor !== false && <Editor product={editor} close={() => setEditor(false)} save={(product) => { onSave(product); setEditor(false) }} />}</section>
}

function RealAdminDashboard({ products, onSave, onLogout }: { products: Product[]; onSave: (product: Product) => Promise<void>; onLogout: () => void }) {
  const { formatMoney } = useCurrency()
  const [overview, setOverview] = useState<AdminOverview | null>(null)
  const [orders, setOrders] = useState<AdminOrder[]>([])
  const [section, setSection] = useState<'overview' | 'products' | 'orders'>('overview')
  const [editor, setEditor] = useState<Product | null | false>(false)
  const [orderEditor, setOrderEditor] = useState(false)
  const [notice, setNotice] = useState('')
  const [error, setError] = useState('')

  const loadData = async () => {
    const [overviewResponse, ordersResponse] = await Promise.all([
      fetch('/api/admin/overview', { credentials: 'same-origin' }),
      fetch('/api/admin/orders', { credentials: 'same-origin' }),
    ])
    if (!overviewResponse.ok || !ordersResponse.ok) throw new Error('dashboard-unavailable')
    setOverview(await overviewResponse.json() as AdminOverview)
    setOrders(await ordersResponse.json() as AdminOrder[])
  }
  useEffect(() => { loadData().catch(() => setError('The admin data could not be loaded. Refresh and try again.')) }, [])

  const updateStatus = async (id: number, status: AdminOrder['status']) => {
    const response = await fetch(`/api/admin/orders/${id}`, {
      method: 'PATCH', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    })
    if (!response.ok) { setError('The order status could not be updated.'); return }
    const updated = await response.json() as AdminOrder
    setOrders((items) => items.map((item) => item.id === updated.id ? updated : item))
    setOverview((value) => value ? { ...value, recentOrders: value.recentOrders.map((item) => item.id === updated.id ? updated : item), pendingOrderCount: orders.filter((item) => item.status === 'pending' && item.id !== updated.id).length + (updated.status === 'pending' ? 1 : 0) } : value)
  }
  const revenue = orders.reduce((sum, order) => sum + order.total, 0)
  const topProducts = products.map((product) => ({
    product,
    units: orders.reduce((sum, order) => sum + order.items.filter((item) => item.productId === product.id).reduce((itemSum, item) => itemSum + item.quantity, 0), 0),
  })).filter((item) => item.units > 0).sort((a, b) => b.units - a.units).slice(0, 5)
  const finishSave = async (product: Product) => {
    try { await onSave(product); setEditor(false); setNotice('Product saved to this workspace.'); setError('') }
    catch { setError('The product could not be saved. Check the form and try again.') }
  }
  const finishOrder = async () => {
    setOrderEditor(false); setNotice('Manual order added.'); setError('')
    try { await loadData() } catch { setError('The order was added, but the dashboard could not refresh.') }
  }
  const dateLabel = (value: string) => new Date(value).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })

  return <section className="admin-page"><aside className="admin-sidebar"><div className="admin-logo"><img src="/basket-logo.png" alt="" /><span>Basket<br /><b>Fast</b></span></div><span className="admin-label">Workspace</span><button className={`admin-nav ${section === 'overview' ? 'active' : ''}`} onClick={() => setSection('overview')}><LayoutDashboard size={17} /> Overview</button><button className={`admin-nav ${section === 'products' ? 'active' : ''}`} onClick={() => setSection('products')}><Package size={17} /> Products <span>{overview?.productCount ?? products.length}</span></button><button className={`admin-nav ${section === 'orders' ? 'active' : ''}`} onClick={() => setSection('orders')}><ShoppingCart size={17} /> Orders <span>{overview?.orderCount ?? orders.length}</span></button><span className="admin-label">Manage</span><button className="admin-nav" onClick={() => setOrderEditor(true)}><Plus size={17} /> Add order</button><div className="admin-user"><span className="avatar">BF</span><span><b>Basket Fast</b><small>Local workspace</small></span><ChevronDown size={15} /></div></aside><div className="admin-main"><div className="admin-topbar"><div><span className="section-kicker">Live workspace data</span><h1>{section === 'orders' ? 'Your orders.' : section === 'products' ? 'Your catalog.' : 'Good morning, team'} <span className="admin-mark">+</span></h1></div><div className="admin-top-actions"><button className="button admin-logout" onClick={onLogout}>Log out</button><button className="button button-dark" onClick={() => section === 'orders' ? setOrderEditor(true) : setEditor(null)}><Plus size={16} /> {section === 'orders' ? 'Add order' : 'Add product'}</button></div></div>{notice && <div className="admin-notice"><Check size={16} /> {notice}</div>}{error && <div className="admin-notice admin-notice-error">{error}</div>}{section === 'overview' && <><div className="admin-stats"><Stat icon={CreditCard} label="Saved revenue" value={formatMoney(revenue)} change="From saved orders" /><Stat icon={ShoppingCart} label="Orders" value={`${overview?.orderCount ?? orders.length}`} change={`${overview?.pendingOrderCount ?? 0} pending`} /><Stat icon={Package} label="Products" value={`${overview?.productCount ?? products.length}`} change="In this catalog" /><Stat icon={Star} label="Reviews" value={`${overview?.reviewCount ?? 0}`} change="Manually entered" /></div><div className="admin-grid"><div className="panel sales-panel"><div className="panel-heading"><div><h2>Order activity</h2><span>Calculated from saved orders</span></div></div>{orders.length ? <div className="live-order-summary">{(['pending', 'confirmed', 'packed', 'shipped', 'delivered', 'cancelled'] as const).map((status) => <div className="live-order-row" key={status}><span className={`status ${status}`}>{status}</span><strong>{orders.filter((order) => order.status === status).length}</strong></div>)}</div> : <div className="admin-empty"><ShoppingCart size={28} /><strong>No orders yet</strong><span>Add a manual order from the Orders section when a customer orders.</span></div>}</div><div className="panel top-products"><div className="panel-heading"><div><h2>Top products</h2><span>Based on saved order items</span></div><button className="text-button" onClick={() => setSection('products')}>Catalog <ArrowRight size={15} /></button></div>{topProducts.length ? <div className="top-product-list">{topProducts.map(({ product, units }, index) => <div className="top-product" key={product.id}><span className="top-rank">0{index + 1}</span><img src={product.image} alt="" /><span className="top-product-name"><b>{product.name}</b><small>{product.category}</small></span><strong>{units}</strong><button className="admin-edit" onClick={() => setEditor(product)}><Pencil size={13} /></button></div>)}</div> : <div className="admin-empty compact"><Package size={24} /><span>Product rankings appear after orders are added.</span></div>}</div></div></>}{section === 'products' && <div className="panel recent-orders"><div className="panel-heading"><div><h2>Catalog</h2><span>Products available in the storefront</span></div><button className="button button-orange" onClick={() => setEditor(null)}><Plus size={15} /> Add product</button></div><table><thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Reviews</th><th>Action</th></tr></thead><tbody>{products.length ? products.map((product) => <tr key={product.id}><td><span className="top-product-name"><b>{product.name}</b><small>{product.tag}</small></span></td><td>{product.category}</td><td><b>{formatMoney(product.price)}</b></td><td>{product.reviews || '—'}</td><td><button className="admin-edit" onClick={() => setEditor(product)}><Pencil size={13} /></button></td></tr>) : <tr><td colSpan={5}>No products in the catalog.</td></tr>}</tbody></table></div>}{section === 'orders' && <div className="panel recent-orders"><div className="panel-heading"><div><h2>Orders</h2><span>Orders entered in this workspace</span></div><button className="button button-orange" onClick={() => setOrderEditor(true)}><Plus size={15} /> Add order</button></div><table><thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Date</th><th>Total</th><th>Status</th></tr></thead><tbody>{orders.length ? orders.map((order) => <tr key={order.id}><td><b>#BF-{String(order.id).padStart(4, '0')}</b></td><td><b>{order.customerName}</b><small>{order.phone}</small></td><td>{order.items.length === 1 ? order.items[0].name : `${order.items.length} items`}</td><td>{dateLabel(order.createdAt)}</td><td><b>{formatMoney(order.total)}</b></td><td><select className="order-status-select" value={order.status} onChange={(event) => updateStatus(order.id, event.target.value as AdminOrder['status'])}>{['pending', 'confirmed', 'packed', 'shipped', 'delivered', 'cancelled'].map((status) => <option key={status}>{status}</option>)}</select></td></tr>) : <tr><td colSpan={6}>No orders yet. Add the first one manually.</td></tr>}</tbody></table></div>}{editor !== false && <Editor product={editor} close={() => setEditor(false)} save={finishSave} />}{orderEditor && <ManualOrderEditor products={products} close={() => setOrderEditor(false)} created={finishOrder} />}</div></section>
}

function ManualOrderEditor({ products, close, created }: { products: Product[]; close: () => void; created: () => Promise<void> }) {
  const [customerName, setCustomerName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [address, setAddress] = useState('')
  const [productId, setProductId] = useState(products[0]?.id ? `${products[0].id}` : '')
  const [quantity, setQuantity] = useState('1')
  const [size, setSize] = useState('M')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setBusy(true); setError('')
    const response = await fetch('/api/admin/orders', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ customerName, email: email || null, phone, address, items: [{ productId: Number(productId), quantity: Number(quantity), size: size || null }] }) })
    if (!response.ok) { setError('Enter all customer details and choose an available product.'); setBusy(false); return }
    await created()
  }
  return <div className="overlay modal-overlay"><div className="editor-modal manual-order-modal"><button className="close-button" onClick={close}><X size={20} /></button><span className="section-kicker">Admin / Orders</span><h2>Add a manual order.</h2><p>Record an order received outside the storefront checkout.</p><form className="editor-form" onSubmit={submit}><label>Customer name<input required value={customerName} onChange={(event) => setCustomerName(event.target.value)} /></label><div className="editor-row"><label>Phone<input required value={phone} onChange={(event) => setPhone(event.target.value)} /></label><label>Email<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} /></label></div><label>Delivery address<textarea required rows={3} value={address} onChange={(event) => setAddress(event.target.value)} /></label><div className="editor-row"><label>Product<select required value={productId} onChange={(event) => setProductId(event.target.value)}>{products.map((product) => <option key={product.id} value={product.id}>{product.name}</option>)}</select></label><label>Quantity<input required min="1" max="25" type="number" value={quantity} onChange={(event) => setQuantity(event.target.value)} /></label></div><label>Size<input value={size} onChange={(event) => setSize(event.target.value)} placeholder="M or One size" /></label>{error && <p className="admin-login-error">{error}</p>}<button className="button button-orange full-button" disabled={busy}>{busy ? 'Saving order...' : 'Save order'} <Check size={16} /></button></form></div></div>
}

function Admin({ products, onSave }: { products: Product[]; onSave: (product: Product) => Promise<void> }) {
  const [authenticated, setAuthenticated] = useState<boolean | null>(null)
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    let active = true
    fetch('/api/admin/session', { credentials: 'same-origin' })
      .then((response) => response.ok ? response.json() : { authenticated: false })
      .then((data: { authenticated?: boolean }) => active && setAuthenticated(data.authenticated === true))
      .catch(() => active && setAuthenticated(false))
    return () => { active = false }
  }, [])

  const login = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!password.trim()) return setError('Enter the workspace password.')
    setBusy(true); setError('')
    try {
      const response = await fetch('/api/admin/login', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) })
      if (response.status === 401) throw new Error('wrong-password')
      if (response.status === 429) throw new Error('rate-limited')
      if (response.status === 503) throw new Error('not-configured')
      if (!response.ok) throw new Error('unavailable')
      const sessionResponse = await fetch('/api/admin/session', { credentials: 'same-origin' })
      const session = await sessionResponse.json() as { authenticated?: boolean }
      if (!session.authenticated) throw new Error('wrong-password')
      setAuthenticated(true); setPassword('')
    } catch (reason) {
      const message = reason instanceof Error ? reason.message : 'unavailable'
      setError(message === 'wrong-password'
        ? 'That password did not match. Try again.'
        : message === 'rate-limited'
          ? 'Too many attempts. Please wait a little before trying again.'
          : message === 'not-configured'
            ? 'Admin sign-in is not configured. Please contact the store owner.'
            : 'The sign-in service is unavailable right now. Please try again.')
    } finally {
      setBusy(false)
    }
  }

  const logout = async () => {
    await fetch('/api/admin/logout', { method: 'POST', credentials: 'same-origin' }).catch(() => undefined)
    setAuthenticated(false)
  }

  if (authenticated === null) return <section className="admin-access-page admin-checking"><div className="admin-access-card"><span className="access-mark"><RefreshCw size={20} /></span><span className="section-kicker">Basket Fast / Secure workspace</span><h1>Checking<br /><em>your pass.</em></h1><p>Verifying the admin session before we open the dashboard.</p><div className="access-bar"><i /></div></div></section>
  if (!authenticated) return <section className="admin-access-page"><div className="admin-access-card"><span className="access-mark"><Lock size={20} /></span><span className="section-kicker">Basket Fast / Secure workspace</span><h1>Backstage<br /><em>access.</em></h1><p>The storefront is for everyone. This door is for the team.</p><form className="admin-login-form" onSubmit={login}><label>Password<input autoFocus autoComplete="current-password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Enter workspace password" /></label>{error && <p className="admin-login-error">{error}</p>}<button className="button button-orange full-button" disabled={busy}>{busy ? 'Checking access...' : 'Enter dashboard'} <ArrowRight size={16} /></button></form><button className="text-button access-home" onClick={() => { window.history.pushState({}, '', '/'); window.dispatchEvent(new PopStateEvent('popstate')) }}>Return to storefront <ArrowRight size={15} /></button></div><div className="admin-access-art"><span>BF / 01</span><strong>NO<br />BENCH-<br /><em>WARMERS.</em></strong><small>Private workspace · Basket Fast</small></div></section>
  return <RealAdminDashboard products={products} onSave={onSave} onLogout={logout} />
}

function Contact() {
  const [opened, setOpened] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' })
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const subject = form.subject || 'Basket Fast contact'
    const body = `Name: ${form.name}\nEmail: ${form.email}\n\n${form.message}`
    setOpened(true)
    window.location.href = `mailto:hello@basketfast.co?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
  }
  return <section className="contact-page"><div className="contact-intro"><span className="section-kicker">Contact / On the line</span><h1>Let’s talk<br /><em>shop.</em></h1><p>Questions about a fit, a print, or where your order is headed? Leave a note and we’ll get back to the game.</p><div className="contact-details"><a href="mailto:hello@basketfast.co"><Mail size={16} /><span><small>Email</small>hello@basketfast.co</span></a><a href="tel:+919876543210"><MessageCircle size={16} /><span><small>Phone</small>+91 98765 43210</span></a><span><span className="contact-detail-icon"><Settings size={16} /></span><span><small>Hours</small>Mon — Fri, 9am — 6pm IST</span></span></div></div><form className="contact-form" onSubmit={submit}><div className="contact-form-head"><span className="section-kicker">01 / Your note</span><span>We open your mail app — nothing is sent from this page.</span></div><label>Your name<input required value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} placeholder="Your name" /></label><label>Your email<input required type="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} placeholder="you@example.com" /></label><label>Subject<input value={form.subject} onChange={(event) => setForm({ ...form, subject: event.target.value })} placeholder="What can we help with?" /></label><label>Message<textarea required rows={6} value={form.message} onChange={(event) => setForm({ ...form, message: event.target.value })} placeholder="Tell us what is on your mind..." /></label><button className="button button-orange full-button" type="submit">Open mail app <Send size={16} /></button>{opened && <p className="contact-opened"><Check size={15} /> Your mail app should be opening with the note addressed to hello@basketfast.co.</p>}</form></section>
}

function LoadingScreen({ navigate }: { navigate: (view: View) => void }) {
  return <section className="status-page loading-page"><div className="status-orbit"><span /><span /><span /><b>BF</b></div><span className="section-kicker">Basket Fast / Loading court</span><h1>Warming up<br /><em>the next play.</em></h1><p>Pulling the latest pieces from the locker room.</p><div className="loading-track"><i /></div><button className="text-button" onClick={() => navigate('home')}>Skip to storefront <ArrowRight size={15} /></button></section>
}

function OfflineScreen({ navigate }: { navigate: (view: View) => void }) {
  return <section className="status-page offline-page"><div className="offline-score"><span>NO SIGNAL</span><strong>0 : 0</strong><small>THE INTERNET</small></div><span className="section-kicker">Basket Fast / Sideline mode</span><h1>The court<br /><em>can wait.</em></h1><p>Your connection dropped. We’ll bring you back to the last play automatically when you’re online again.</p><div className="status-actions"><button className="button button-orange" onClick={() => window.navigator.onLine ? navigate('home') : window.location.reload()}>Try again <RefreshCw size={16} /></button><button className="text-button" onClick={() => navigate('home')}>Back to home <ArrowRight size={15} /></button></div></section>
}

function NotFound({ navigate }: { navigate: (view: View) => void }) {
  return <section className="status-page not-found-page"><div className="not-found-number">404</div><span className="section-kicker">Basket Fast / Out of bounds</span><h1>That play<br /><em>isn’t here.</em></h1><p>The page you’re looking for took a bad bounce. Let’s get you back in the rotation.</p><button className="button button-dark" onClick={() => navigate('home')}>Return to storefront <ArrowUpRight size={16} /></button></section>
}

function Stat({ icon: Icon, label, value, change }: { icon: typeof CreditCard; label: string; value: string; change: string }) { return <div className="stat-card"><span className="stat-icon"><Icon size={18} /></span><span className="stat-label">{label}</span><strong>{value}</strong><small><ArrowUpRight size={12} /> {change} <span>vs last month</span></small></div> }
function Editor({ product, close, save }: { product: Product | null; close: () => void; save: (product: Product) => void | Promise<void> }) {
  const [name, setName] = useState(product?.name || '')
  const [category, setCategory] = useState(product?.category || 'T-shirts')
  const [price, setPrice] = useState(`${product?.price || ''}`)
  const [offerPrice, setOfferPrice] = useState(`${product?.oldPrice || ''}`)
  const [description, setDescription] = useState(product?.description || product?.tag || '')
  const [sizes, setSizes] = useState(product?.sizes?.join(', ') || 'S, M, L, XL')
  const [colors, setColors] = useState(product?.colors?.join(', ') || '#141414, #ff681f')
  const [images, setImages] = useState<string[]>(product?.images?.length ? product.images : [product?.image || '/product-tee.jpg'])
  const [imageUrl, setImageUrl] = useState('')
  const [limited, setLimited] = useState(product?.badge === 'Limited')
  const [saving, setSaving] = useState(false)
  const splitList = (value: string) => value.split(/[,\n]/).map((item) => item.trim()).filter(Boolean)
  const submit = () => {
    if (!name.trim() || !price || !images.length) return
    setSaving(true)
    void Promise.resolve(save({
      id: product?.id || 0,
      name: name.trim(),
      category: category.trim() || 'T-shirts',
      price: Number(price),
      oldPrice: offerPrice ? Number(offerPrice) : undefined,
      colors: splitList(colors),
      sizes: splitList(sizes),
      images,
      image: images[0],
      description: description.trim(),
      tag: description.trim() || 'Store piece',
      rating: product?.rating || 0,
      reviews: product?.reviews || 0,
      badge: limited ? 'Limited' : undefined,
    })).finally(() => setSaving(false))
  }
  const addImage = () => {
    const value = imageUrl.trim()
    if (!value || images.includes(value)) return
    setImages((current) => [...current, value])
    setImageUrl('')
  }
  const removeImage = (index: number) => setImages((current) => current.filter((_, itemIndex) => itemIndex !== index))
  const makePrimary = (index: number) => setImages((current) => [current[index], ...current.filter((_, itemIndex) => itemIndex !== index)])
  return <div className="overlay modal-overlay"><div className="editor-modal admin-editor-modal"><button className="close-button" onClick={close} aria-label="Close product editor"><X size={20} /></button><div className="editor-heading"><span className="section-kicker">Admin / Catalog</span><h2>{product ? 'Edit piece.' : 'Add a new piece.'}</h2><p>Build the complete product preview customers will see in the store.</p></div><div className="editor-form"><div className="admin-editor-columns"><div className="admin-editor-fields"><label>Product name<input value={name} onChange={(event) => setName(event.target.value)} placeholder="e.g. Night Shift Tee" /></label><div className="editor-row"><label>Category<input value={category} onChange={(event) => setCategory(event.target.value)} placeholder="T-shirts" /></label><label>Sale price<input required min="1" type="number" value={price} onChange={(event) => setPrice(event.target.value)} placeholder="5499" /></label></div><div className="editor-row"><label>Compare-at price<input min="0" type="number" value={offerPrice} onChange={(event) => setOfferPrice(event.target.value)} placeholder="Optional" /></label><label className="editor-check"><input type="checkbox" checked={limited} onChange={(event) => setLimited(event.target.checked)} /> Limited piece</label></div><label>Description<textarea value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Tell customers what makes this piece worth the rotation." rows={4} /></label><div className="editor-row"><label>Sizes <small>Comma separated</small><input value={sizes} onChange={(event) => setSizes(event.target.value)} placeholder="S, M, L, XL" /></label><label>Colors <small>Hex or CSS values</small><input value={colors} onChange={(event) => setColors(event.target.value)} placeholder="#141414, #ff681f" /></label></div></div><div className="admin-editor-media"><div className="media-heading"><div><strong>Product images</strong><small>First image is the cover.</small></div><span>{images.length}/12</span></div><div className="editor-image-grid">{images.map((image, index) => <div className={`editor-image-card ${index === 0 ? 'is-primary' : ''}`} key={`${image}-${index}`}><img src={image} alt="" /><span>{index === 0 ? 'Cover' : `View ${index + 1}`}</span><div><button type="button" onClick={() => makePrimary(index)} disabled={index === 0}>Use cover</button><button type="button" onClick={() => removeImage(index)} aria-label={`Remove image ${index + 1}`}><X size={13} /></button></div></div>)}</div><div className="add-image-row"><input value={imageUrl} onChange={(event) => setImageUrl(event.target.value)} onKeyDown={(event) => event.key === 'Enter' && (event.preventDefault(), addImage())} placeholder="Paste an image URL" /><button type="button" onClick={addImage} disabled={!imageUrl.trim() || images.length >= 12}><Plus size={15} /> Add</button></div></div></div><div className="editor-preview"><img src={images[0]} alt="" /><div><strong>{name || 'Your new piece'}</strong><span>{description || 'Your product description will appear here.'}</span></div></div><button className="button button-orange full-button" onClick={submit} disabled={saving || !name.trim() || !price || !images.length}><Check size={16} /> {saving ? 'Saving piece...' : product ? 'Save changes' : 'Publish product'}</button></div></div></div>
}

function Footer({ navigate, openPolicy }: { navigate: (view: View) => void; openPolicy: (title: string) => void }) { return <footer className="site-footer"><div className="footer-main"><div className="footer-brand"><button className="brand brand-footer" onClick={() => navigate('home')}><img src="/basket-logo.png" alt="Basket logo" /><span>BASKET <b>FAST</b></span></button><p>For the ones who<br /><em>never stop moving.</em></p><div className="socials"><button aria-label="Instagram"><Instagram size={17} /></button><button aria-label="Twitter"><Twitter size={17} /></button><button aria-label="Email" onClick={() => navigate('contact')}><Mail size={17} /></button></div></div><div className="footer-links"><div><span>Explore</span><button onClick={() => navigate('shop')}>Shop all</button><button onClick={() => navigate('collections')}>Collections</button><button onClick={() => navigate('about')}>Our story</button><button onClick={() => navigate('journal')}>Journal</button></div><div><span>Help</span><button onClick={() => openPolicy('Shipping & delivery')}>Shipping & delivery</button><button onClick={() => openPolicy('Returns & exchanges')}>Returns & exchanges</button><button onClick={() => openPolicy('Privacy policy')}>Privacy policy</button><button onClick={() => navigate('policies')}>All policies</button></div><div><span>Contact</span><button onClick={() => navigate('contact')}>Contact the team</button><a href="mailto:hello@basketfast.co">hello@basketfast.co</a><a href="tel:+919876543210">+91 98765 43210</a><small>Mon — Fri, 9am — 6pm IST</small></div></div></div><div className="footer-bottom"><span>© 2026 Basket Fast. Built for the game.</span><span><Lock size={12} /> Secure checkout</span><span>Made with intention in India</span></div></footer> }

function Cart({ cart, close, remove }: { cart: Product[]; close: () => void; remove: (id: number, index: number) => void }) {
  const { formatMoney } = useCurrency()
  const [ordered, setOrdered] = useState(false)
  const total = cart.reduce((sum, item) => sum + item.price, 0)
  return <div className="overlay"><aside className="cart-drawer"><div className="drawer-header"><div><span className="section-kicker">Your rotation</span><h2>Shopping bag <span>({cart.length})</span></h2></div><button className="close-button" onClick={close}><X size={20} /></button></div>{ordered ? <div className="empty-cart order-confirmation"><Check size={38} /><h3>Order received.</h3><p>This is a preview checkout. Your rotation is reserved while the store goes live.</p><button className="button button-dark" onClick={close}>Back to store</button></div> : cart.length ? <><div className="cart-items">{cart.map((item, index) => <div className="cart-item" key={`${item.id}-${index}`}><img src={item.image} alt={item.name} /><div><span>{item.category}</span><h3>{item.name}</h3>{(item.selectedSize || item.selectedColor) && <small className="cart-variant">{item.selectedColor ? 'Color selected' : ''}{item.selectedColor && item.selectedSize ? ' · ' : ''}{item.selectedSize ? `Size ${item.selectedSize}` : ''}</small>}<b>{formatMoney(item.price)}</b><button onClick={() => remove(item.id, index)}>Remove</button></div></div>)}</div><div className="drawer-bottom"><div className="cart-summary"><span>Subtotal</span><strong>{formatMoney(total)}</strong></div><p><Truck size={14} /> {total >= FREE_SHIPPING_THRESHOLD ? 'You qualify for free shipping.' : `You’re ${formatMoney(Math.max(0, FREE_SHIPPING_THRESHOLD - total))} away from free shipping.`}</p><button className="button button-orange checkout-button" onClick={() => setOrdered(true)}>Checkout <ArrowUpRight size={17} /></button><small><Lock size={11} /> Secure checkout · Taxes calculated at checkout</small></div></> : <div className="empty-cart"><ShoppingBag size={37} /><h3>Your bag is waiting.</h3><p>Add a few pieces and your next rotation is ready.</p><button className="button button-dark" onClick={close}>Keep shopping</button></div>}</aside></div>
}

function ProductModal({ product, close, add }: { product: Product; close: () => void; add: (product: Product) => void }) {
  const { formatMoney } = useCurrency()
  const images = product.images.length ? product.images : [product.image]
  const sizes = product.sizes.length ? product.sizes : ['One size']
  const [activeImage, setActiveImage] = useState(0)
  const [selectedSize, setSelectedSize] = useState(sizes[0])
  const [selectedColor, setSelectedColor] = useState(product.colors[0] || '')
  useEffect(() => {
    setActiveImage(0)
    setSelectedSize(sizes[0])
    setSelectedColor(product.colors[0] || '')
  }, [product.id])
  return <div className="overlay modal-overlay"><div className="product-modal"><button className="close-button modal-close" onClick={close} aria-label="Close product preview"><X size={20} /></button><div className="product-media"><div className="modal-image"><img src={images[activeImage]} alt={`${product.name} view ${activeImage + 1}`} /></div>{images.length > 1 && <div className="product-thumbnails" aria-label="Product images">{images.map((image, index) => <button key={`${image}-${index}`} className={activeImage === index ? 'active' : ''} onClick={() => setActiveImage(index)} aria-label={`Show image ${index + 1}`}><img src={image} alt="" /></button>)}</div>}</div><div className="modal-info"><span className="section-kicker">{product.category} / {product.tag}</span><h2>{product.name}</h2><div className="modal-rating">{product.rating > 0 ? <><Star size={14} fill="currentColor" /> {product.rating} / {product.reviews} reviews</> : 'New piece · Just added'}</div><p className="modal-price">{formatMoney(product.price)} {product.oldPrice && <del>{formatMoney(product.oldPrice)}</del>}</p><p className="modal-description">{product.description}</p><div className="select-line"><span>Color <b>{selectedColor || 'Standard'}</b></span><div className="modal-swatches">{product.colors.map((color) => <button key={color} className={selectedColor === color ? 'selected' : ''} style={{ background: color }} onClick={() => setSelectedColor(color)} aria-label={`Select color ${color}`} />)}</div></div><div className="select-line"><span>Size</span><div className="sizes">{sizes.map((size) => <button key={size} className={selectedSize === size ? 'selected' : ''} onClick={() => setSelectedSize(size)}>{size}</button>)}</div></div><button className="button button-orange full-button" onClick={() => add(product, { size: selectedSize, color: selectedColor })}>Add to bag <ShoppingBag size={17} /></button><div className="modal-perks"><span><Truck size={15} /> Free shipping over {formatMoney(FREE_SHIPPING_THRESHOLD)}</span><span><RefreshCw size={14} /> Easy 30-day returns</span></div></div></div></div>
}

function Chat({ open, setOpen }: { open: boolean; setOpen: (value: boolean) => void }) { const [draft, setDraft] = useState(''); const [sent, setSent] = useState<string[]>([]); const send = () => { if (!draft.trim()) return; setSent((messages) => [...messages, draft.trim()]); setDraft(''); }; return <><button className="chat-button" onClick={() => setOpen(!open)}><span className="chat-pulse" /><MessageCircle size={22} /> <span>Need a hand?</span></button>{open && <div className="chat-window"><div className="chat-header"><span className="chat-avatar"><Sparkles size={15} /></span><div><b>Fast assist</b><small>Usually replies instantly</small></div><button onClick={() => setOpen(false)}><X size={16} /></button></div><div className="chat-body"><div className="chat-message">Hey! Looking for a size, tracking an order, or just browsing the new drop?</div>{sent.map((message, index) => <div className="chat-message chat-message-sent" key={`${message}-${index}`}>{message}</div>)}<div className="chat-options"><button onClick={() => setDraft('Help me pick a size')}>Help me pick a size</button><button onClick={() => setDraft('Where is my order?')}>Where is my order?</button><button onClick={() => setDraft('Talk to a human')}>Talk to a human</button></div></div><div className="chat-input"><input value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => event.key === 'Enter' && send()} placeholder="Type a message..." /><button aria-label="Send message" onClick={send}><Send size={16} /></button></div></div>}</> }
function Feedback({ onOpen }: { onOpen: () => void }) { return <button className="feedback-tab" onClick={onOpen}><MessageCircle size={15} /> Feedback</button> }
function FeedbackModal({ close }: { close: () => void }) { const [sent, setSent] = useState(false); return <div className="overlay modal-overlay"><div className="feedback-modal"><button className="close-button" onClick={close}><X size={20} /></button><span className="section-kicker">Basket Fast / Your take</span><h2>Keep us<br /><em>moving.</em></h2>{sent ? <div className="feedback-success"><Check size={23} /><p>Thanks for the note. We read every one.</p><button className="button button-dark" onClick={close}>Close</button></div> : <><p>Tell us what felt good, what felt slow, or what you want to see next.</p><textarea placeholder="Your feedback..." rows={4} /><button className="button button-orange full-button" onClick={() => setSent(true)}>Send feedback <Send size={15} /></button></>}</div></div> }
function PolicyModal({ title, close }: { title: string; close: () => void }) { return <div className="overlay modal-overlay"><div className="policy-modal"><button className="close-button" onClick={close}><X size={20} /></button><span className="policy-icon"><ShieldCheck size={22} /></span><span className="section-kicker">Basket Fast / {title}</span><h2>{title}</h2><p className="policy-intro">Fast, clear, and trackable. We keep the details simple so you can focus on the game.</p><ul>{['Free standard shipping on orders over $75.', 'Standard delivery takes 3–7 business days across India.', 'Start returns within 30 days for unworn items.', 'Questions? Email hello@basketfast.co.'].map((item) => <li key={item}><Check size={16} />{item}</li>)}</ul><button className="button button-dark" onClick={close}>Got it</button></div></div> }