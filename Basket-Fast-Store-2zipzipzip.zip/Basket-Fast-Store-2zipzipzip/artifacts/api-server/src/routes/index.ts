import { Router, type IRouter } from "express";
import healthRouter from "./health";
import adminRouter from "./admin";
import catalogRouter from "./catalog";
import ordersRouter from "./orders";
import overviewRouter from "./overview";

const router: IRouter = Router();

router.use(healthRouter);
router.use(adminRouter);
router.use(catalogRouter);
router.use(ordersRouter);
router.use(overviewRouter);

export default router;
