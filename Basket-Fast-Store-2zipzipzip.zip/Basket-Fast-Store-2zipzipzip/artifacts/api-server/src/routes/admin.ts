import { createHmac, timingSafeEqual } from "node:crypto";
import { Router, type IRouter, type RequestHandler } from "express";
import {
  AdminLoginBody,
  AdminLoginResponse,
  AdminLogoutResponse,
  GetAdminSessionResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();
const cookieName = "basket_fast_admin";
const cookiePath = "/api/admin";
const sessionLifetimeMs = 8 * 60 * 60 * 1000;
const attemptWindowMs = 15 * 60 * 1000;
const maxAttempts = 10;
const attemptsByIp = new Map<string, { count: number; startedAt: number }>();

function sessionSignature(expiresAt: number, secret: string): string {
  return createHmac("sha256", secret)
    .update(`basket-fast-admin:${expiresAt}`)
    .digest("hex");
}

function validSession(value: unknown, secret: string | undefined): boolean {
  if (typeof value !== "string" || !secret || !process.env.ADMIN_PASSWORD) return false;
  const match = /^(\d{13})\.([a-f0-9]{64})$/.exec(value);
  if (!match) return false;

  const expiresAt = Number(match[1]);
  if (!Number.isSafeInteger(expiresAt) || expiresAt <= Date.now()) return false;

  const actual = Buffer.from(match[2], "hex");
  const expected = Buffer.from(sessionSignature(expiresAt, secret), "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

export const requireAdmin: RequestHandler = (req, res, next) => {
  if (!validSession(req.cookies?.[cookieName], process.env.SESSION_SECRET)) {
    res.status(401).json({ message: "Admin session required." });
    return;
  }
  next();
};

function cookieOptions() {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict" as const,
    path: cookiePath,
  };
}

router.get("/admin/session", (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json(
    GetAdminSessionResponse.parse({
      authenticated: validSession(req.cookies?.[cookieName], process.env.SESSION_SECRET),
    }),
  );
});

router.post("/admin/login", (req, res) => {
  res.setHeader("Cache-Control", "no-store");

  const adminPassword = process.env.ADMIN_PASSWORD;
  const sessionSecret = process.env.SESSION_SECRET;
  if (!adminPassword || !sessionSecret) {
    res.status(503).json({ message: "Admin sign-in is not configured." });
    return;
  }

  const parsed = AdminLoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Enter your admin password." });
    return;
  }

  const now = Date.now();
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const currentAttempts = attemptsByIp.get(ip);
  if (!currentAttempts || now - currentAttempts.startedAt >= attemptWindowMs) {
    attemptsByIp.set(ip, { count: 1, startedAt: now });
  } else if (currentAttempts.count >= maxAttempts) {
    res.setHeader("Retry-After", String(Math.ceil((attemptWindowMs - (now - currentAttempts.startedAt)) / 1000)));
    res.status(429).json({ message: "Too many attempts. Please wait and try again." });
    return;
  } else {
    currentAttempts.count += 1;
  }

  if (attemptsByIp.size > 1000) {
    for (const [key, entry] of attemptsByIp) {
      if (now - entry.startedAt >= attemptWindowMs) attemptsByIp.delete(key);
    }
  }

  const passwordHash = createHmac("sha256", sessionSecret)
    .update(parsed.data.password)
    .digest();
  const expectedHash = createHmac("sha256", sessionSecret)
    .update(adminPassword)
    .digest();
  if (!timingSafeEqual(passwordHash, expectedHash)) {
    res.status(401).json({ message: "That password didn’t match. Try again." });
    return;
  }

  attemptsByIp.delete(ip);
  const expiresAt = now + sessionLifetimeMs;
  const token = `${expiresAt}.${sessionSignature(expiresAt, sessionSecret)}`;
  res.cookie(cookieName, token, {
    ...cookieOptions(),
    maxAge: sessionLifetimeMs,
  });
  res.json(AdminLoginResponse.parse({ authenticated: true }));
});

router.post("/admin/logout", (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.clearCookie(cookieName, cookieOptions());
  res.json(AdminLogoutResponse.parse({ authenticated: false }));
});

export default router;