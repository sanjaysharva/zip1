import { Router, type IRouter } from "express";
import { GetAdminOverviewResponse } from "@workspace/api-zod";
import { orders, products } from "../store";
import { requireAdmin } from "./admin";

const router: IRouter = Router();

router.get("/admin/overview", requireAdmin, (_req, res) => {
  res.json(GetAdminOverviewResponse.parse({
    productCount: products.length,
    orderCount: orders.length,
    pendingOrderCount: orders.filter((order) => order.status === "pending").length,
    reviewCount: 0,
    recentOrders: orders.slice(0, 8),
  }));
});

export default router;