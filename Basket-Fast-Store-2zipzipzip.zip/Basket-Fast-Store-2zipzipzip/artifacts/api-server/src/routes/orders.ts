import { Router, type IRouter } from "express";
import { CreateManualOrderBody, CreateManualOrderResponse, CreateOrderBody, CreateOrderResponse, ListOrdersResponse, UpdateOrderBody, UpdateOrderResponse } from "@workspace/api-zod";
import { allocateOrderId, orders, products, type StoreOrder, type StoreOrderItem } from "../store";
import { requireAdmin } from "./admin";

const router: IRouter = Router();
const responseOrder = (order: StoreOrder) => order;

function createOrder(req: { body: unknown }, res: { status: (code: number) => { json: (body: unknown) => void } }, schema: typeof CreateOrderBody | typeof CreateManualOrderBody) {
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Enter valid customer and item details." });
    return null;
  }
  const items = parsed.data.items.map((item) => {
    const product = products.find((candidate) => candidate.id === item.productId);
    if (!product) return null;
    return {
      productId: product.id,
      name: product.name,
      category: product.category,
      price: product.offerPrice ?? product.price,
      quantity: item.quantity,
      size: item.size,
      image: product.images[0] ?? "",
    };
  });
  if (items.some((item) => item === null)) {
    res.status(400).json({ message: "One or more selected products are unavailable." });
    return null;
  }
  const order: StoreOrder = {
    id: allocateOrderId(),
    customerName: parsed.data.customerName,
    email: parsed.data.email,
    phone: parsed.data.phone,
    address: parsed.data.address,
    items: items as StoreOrderItem[],
    total: items.reduce((sum, item) => sum + (item?.price ?? 0) * (item?.quantity ?? 0), 0),
    status: "pending",
    createdAt: new Date(),
  };
  orders.unshift(order);
  return order;
}

router.post("/orders", (req, res) => {
  const order = createOrder(req, res, CreateOrderBody);
  if (order) res.status(201).json(CreateOrderResponse.parse(responseOrder(order)));
});

router.get("/admin/orders", requireAdmin, (_req, res) => {
  res.json(ListOrdersResponse.parse(orders));
});

router.post("/admin/orders", requireAdmin, (req, res) => {
  const order = createOrder(req, res, CreateManualOrderBody);
  if (order) res.status(201).json(CreateManualOrderResponse.parse(responseOrder(order)));
});

router.patch("/admin/orders/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const parsed = UpdateOrderBody.safeParse(req.body);
  const order = orders.find((item) => item.id === id);
  if (!Number.isInteger(id) || !parsed.success) {
    res.status(400).json({ message: "Enter a valid order status." });
    return;
  }
  if (!order) {
    res.status(404).json({ message: "Order not found." });
    return;
  }
  order.status = parsed.data.status;
  res.json(UpdateOrderResponse.parse(responseOrder(order)));
});

export default router;