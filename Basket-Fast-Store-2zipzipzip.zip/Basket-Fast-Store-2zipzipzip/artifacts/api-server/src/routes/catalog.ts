import { Router, type IRouter } from "express";
import { CreateProductBody, CreateProductResponse, ListProductsResponse, UpdateProductBody, UpdateProductResponse } from "@workspace/api-zod";
import { allocateProductId, products } from "../store";
import { requireAdmin } from "./admin";

const router: IRouter = Router();
const responseProduct = (product: (typeof products)[number]) => ({
  ...product,
  image: product.images[0] ?? "",
});

router.get("/products", (_req, res) => {
  res.json(ListProductsResponse.parse(products.map(responseProduct)));
});

router.post("/admin/products", requireAdmin, (req, res) => {
  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Enter valid product details." });
    return;
  }
  const now = new Date();
  const product = {
    id: allocateProductId(),
    ...parsed.data,
    averageRating: 0,
    reviewCount: 0,
    createdAt: now,
    updatedAt: now,
  };
  products.unshift(product);
  res.status(201).json(CreateProductResponse.parse(responseProduct(product)));
});

router.patch("/admin/products/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const parsed = UpdateProductBody.safeParse(req.body);
  const product = products.find((item) => item.id === id);
  if (!Number.isInteger(id) || !parsed.success) {
    res.status(400).json({ message: "Enter valid product details." });
    return;
  }
  if (!product) {
    res.status(404).json({ message: "Product not found." });
    return;
  }
  Object.assign(product, parsed.data, { updatedAt: new Date() });
  res.json(UpdateProductResponse.parse(responseProduct(product)));
});

router.delete("/admin/products/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const index = products.findIndex((item) => item.id === id);
  if (!Number.isInteger(id) || index < 0) {
    res.status(404).json({ message: "Product not found." });
    return;
  }
  products.splice(index, 1);
  res.status(204).send();
});

export default router;