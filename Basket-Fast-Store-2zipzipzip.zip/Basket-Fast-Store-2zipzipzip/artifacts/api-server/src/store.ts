import type { OrderStatus } from "@workspace/api-zod";

export type StoreProduct = {
  id: number;
  name: string;
  category: string;
  description: string | null;
  price: number;
  offerPrice: number | null;
  isLimited: boolean;
  colors: string[];
  sizes: string[];
  images: string[];
  averageRating: number;
  reviewCount: number;
  createdAt: Date;
  updatedAt: Date;
};

export type StoreOrderItem = {
  productId: number;
  name: string;
  category: string;
  price: number;
  quantity: number;
  size: string | null;
  image: string;
};

export type StoreOrder = {
  id: number;
  customerName: string;
  email: string | null;
  phone: string;
  address: string;
  items: StoreOrderItem[];
  total: number;
  status: OrderStatus;
  createdAt: Date;
};

const now = new Date();
const seedProducts: Omit<StoreProduct, "createdAt" | "updatedAt">[] = [
  { id: 1, name: "Fast Break Jersey", category: "Jerseys", description: "A lightweight court-ready jersey for game days and everyday movement.", price: 6699, offerPrice: 5499, isLimited: false, colors: ["#141414", "#ff681f", "#e9e6dc"], sizes: ["S", "M", "L", "XL"], images: ["/product-jersey.jpg"], averageRating: 0, reviewCount: 0 },
  { id: 2, name: "Orange Court Hoodie", category: "Hoodies", description: "Heavyweight cotton with a relaxed fit for warmups and late nights.", price: 6999, offerPrice: null, isLimited: false, colors: ["#ff651e", "#151515"], sizes: ["S", "M", "L", "XL"], images: ["/product-hoodie.jpg"], averageRating: 0, reviewCount: 0 },
  { id: 3, name: "Baseline Script Tee", category: "T-shirts", description: "An everyday essential with a clean court-side graphic.", price: 3299, offerPrice: null, isLimited: false, colors: ["#faf8f1", "#141414", "#ff681f"], sizes: ["S", "M", "L", "XL"], images: ["/product-tee.jpg"], averageRating: 0, reviewCount: 0 },
  { id: 4, name: "The Sixth Man Cap", category: "Accessories", description: "A one-size cap for the walk-in, warmup, and everything after.", price: 2499, offerPrice: null, isLimited: true, colors: ["#141414", "#ff681f"], sizes: ["One size"], images: ["/product-cap.jpg"], averageRating: 0, reviewCount: 0 },
  { id: 5, name: "Court Vision Crew", category: "Sweatshirts", description: "Soft on the inside and easy to layer through the season.", price: 6299, offerPrice: null, isLimited: false, colors: ["#e9e6dc", "#141414"], sizes: ["S", "M", "L", "XL"], images: ["/product-hoodie.jpg"], averageRating: 0, reviewCount: 0 },
  { id: 6, name: "Away Game Shorts", category: "Shorts", description: "Quick-dry mesh built for movement beyond the baseline.", price: 3899, offerPrice: null, isLimited: false, colors: ["#141414", "#ff681f"], sizes: ["S", "M", "L", "XL"], images: ["/product-tee.jpg"], averageRating: 0, reviewCount: 0 },
  { id: 7, name: "Daily Graphic Tee", category: "Graphic tees", description: "An everyday print with a little more energy.", price: 3099, offerPrice: null, isLimited: false, colors: ["#f5f0e5", "#141414", "#ff681f"], sizes: ["S", "M", "L", "XL"], images: ["/product-tee.jpg"], averageRating: 0, reviewCount: 0 },
  { id: 8, name: "Neon Spirit Tee", category: "Anime-inspired", description: "An original graphic tee for the ones who set the tone.", price: 3599, offerPrice: null, isLimited: false, colors: ["#141414", "#ff681f", "#e9e6dc"], sizes: ["S", "M", "L", "XL"], images: ["/editorial-court.jpg"], averageRating: 0, reviewCount: 0 },
  { id: 9, name: "Court Lines Poster Print", category: "Posters", description: "Archival paper print for the wall behind your next play.", price: 1999, offerPrice: null, isLimited: false, colors: ["#f5f0e5", "#ff681f"], sizes: ["A3"], images: ["/lifestyle-court.jpg"], averageRating: 0, reviewCount: 0 },
  { id: 10, name: "After Hours Poster Print", category: "Posters", description: "A limited A3 print for court stories after dark.", price: 2299, offerPrice: null, isLimited: true, colors: ["#141414", "#ff681f"], sizes: ["A3"], images: ["/material-detail.jpg"], averageRating: 0, reviewCount: 0 },
];

export const products: StoreProduct[] = seedProducts.map((product) => ({
  ...product,
  createdAt: now,
  updatedAt: now,
}));
export const orders: StoreOrder[] = [];
let nextProductId = products.length + 1;
let nextOrderId = 1;

export function allocateProductId() {
  return nextProductId++;
}

export function allocateOrderId() {
  return nextOrderId++;
}