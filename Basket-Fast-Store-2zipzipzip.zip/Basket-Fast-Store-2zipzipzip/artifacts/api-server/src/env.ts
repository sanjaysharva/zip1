import { existsSync } from "node:fs";
import { resolve } from "node:path";

const envFiles = [
  resolve(process.cwd(), "artifacts/api-server/.env"),
  resolve(process.cwd(), ".env"),
];

for (const envFile of envFiles) {
  if (existsSync(envFile)) {
    process.loadEnvFile(envFile);
    break;
  }
}