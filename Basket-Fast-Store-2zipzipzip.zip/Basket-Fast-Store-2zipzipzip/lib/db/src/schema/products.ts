import { boolean, integer, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const productsTable = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  price: integer("price").notNull(),
  offerPrice: integer("offer_price"),
  isLimited: boolean("is_limited").notNull().default(false),
  colors: text("colors").array().notNull().default(sql`ARRAY[]::text[]`),
  sizes: text("sizes").array().notNull().default(sql`ARRAY[]::text[]`),
  images: text("images").array().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});